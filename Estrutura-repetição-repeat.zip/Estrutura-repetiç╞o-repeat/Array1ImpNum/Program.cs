﻿using System;

public class Array1{

public static void Main(){

// Declarando array inteiro com 7 números

int[] Array1 = {23, 57, 19, 20, 21, 19, 8};

// Loop para contar todos os números

for (int i = 0; i < Array1.Length; i++){

// Imprimindo o array no console

Console.WriteLine("Número do Array: " +Array1[i]);

}
}
}